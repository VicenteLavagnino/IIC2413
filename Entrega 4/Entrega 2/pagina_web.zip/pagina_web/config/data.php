<?php
$user = 'grupo4';
$password = 'grupo4';
$databaseName = 'grupo4e2';
?>